package connection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class javaconnection {
    public static Connection ConnecrDb()
    //public static void main(String ar[])
    {
        try{
            Class.forName("oracle.jdbc.OracleDriver");
           Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","system");
          return con;
                   
      // Statement stmt=con.createStatement();
    
    //con.close();
        }
    catch(Exception e)
        {
            JOptionPane.showMessageDialog(null,e);
        }
        //return null;
        return null;
        }
}
    
    


